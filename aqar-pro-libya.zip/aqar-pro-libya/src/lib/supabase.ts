import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://vprgjpczzswbwcxpnmgf.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZwcmdqcGN6enN3YndjeHBubWdmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYzMzY4OTMsImV4cCI6MjA3MTkxMjg5M30.mi0Z16w5BWOGSaBHhemOdESwaFkHwSHOWjYTQ1KP_6Q'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types for our application
export interface Property {
  id: string
  title: string
  description: string
  price: number
  currency: string
  listing_type: 'sale' | 'rent'
  rental_period?: 'daily' | 'monthly' | 'yearly'
  area: number
  bedrooms: number
  bathrooms: number
  living_rooms: number
  floor_number?: number
  property_age?: number
  latitude?: number
  longitude?: number
  address_details: string
  status: string
  is_featured: boolean
  views_count: number
  contact_phone: string
  contact_whatsapp?: string
  images: string[]
  amenities: string[]
  created_at: string
  updated_at: string
  city_id: number
  district_id: number
  property_type_id: number
  owner_id: string
  city_name: string
  district_name: string
  property_type_name: string
  property_type_icon: string
  property_type_category: string
  owner_name: string
  owner_phone: string
  owner_verified: boolean
  images_array: string[]
  amenities_array: string[]
}

export interface City {
  id: number
  name_ar: string
  name_en?: string
  latitude?: number
  longitude?: number
  population?: number
  is_major_city: boolean
}

export interface District {
  id: number
  city_id: number
  name_ar: string
  name_en?: string
  latitude?: number
  longitude?: number
  description?: string
}

export interface PropertyType {
  id: number
  name_ar: string
  name_en?: string
  icon?: string
  category: string
  is_active: boolean
  display_order: number
}

export interface SearchFilters {
  query?: string
  cityId?: number
  districtId?: number
  propertyTypeId?: number
  listingType?: 'sale' | 'rent'
  minPrice?: number
  maxPrice?: number
  minArea?: number
  maxArea?: number
  bedrooms?: number
  bathrooms?: number
  page?: number
  limit?: number
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
}

export interface SearchResponse {
  properties: Property[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
    hasNext: boolean
    hasPrev: boolean
  }
  filters: SearchFilters
  summary: {
    totalFound: number
    resultsOnThisPage: number
    searchExecutedAt: string
  }
}