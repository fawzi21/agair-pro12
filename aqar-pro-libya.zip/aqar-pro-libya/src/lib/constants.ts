export const GOOGLE_MAPS_API_KEY = 'AIzaSyCO0kKndUNlmQi3B5mxy4dblg_8WYcuKuk'

// Libya coordinates for map centering
export const LIBYA_CENTER = {
  lat: 26.3351,
  lng: 17.2283
}

// Major Libyan cities
export const MAJOR_CITIES = [
  { name: 'طرابلس', lat: 32.8872, lng: 13.1913 },
  { name: 'بنغازي', lat: 32.1149, lng: 20.0680 },
  { name: 'مصراتة', lat: 32.3745, lng: 15.0919 },
  { name: 'الزاوية', lat: 32.7573, lng: 12.7278 },
  { name: 'ترهونة', lat: 32.4351, lng: 13.6339 }
]

// Map style options
export const MAP_STYLES = [
  {
    featureType: "administrative",
    elementType: "labels.text.fill",
    stylers: [{ color: "#444444" }]
  },
  {
    featureType: "landscape",
    elementType: "all",
    stylers: [{ color: "#f2f2f2" }]
  },
  {
    featureType: "poi",
    elementType: "all",
    stylers: [{ visibility: "off" }]
  },
  {
    featureType: "road",
    elementType: "all",
    stylers: [{ saturation: -100 }, { lightness: 45 }]
  },
  {
    featureType: "road.highway",
    elementType: "all",
    stylers: [{ visibility: "simplified" }]
  },
  {
    featureType: "road.arterial",
    elementType: "labels.icon",
    stylers: [{ visibility: "off" }]
  },
  {
    featureType: "transit",
    elementType: "all",
    stylers: [{ visibility: "off" }]
  },
  {
    featureType: "water",
    elementType: "all",
    stylers: [{ color: "#46bcec" }, { visibility: "on" }]
  }
]