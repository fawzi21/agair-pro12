import React, { useState, useEffect, useCallback } from 'react'
import { Loader2, Search, SlidersHorizontal, Grid3X3, List } from 'lucide-react'
import PropertyCard from './PropertyCard'
import { Property, SearchFilters, SearchResponse } from '@/lib/supabase'

interface PropertyListProps {
  filters?: SearchFilters
  viewType?: 'grid' | 'list'
  onFiltersChange?: (filters: SearchFilters) => void
}

const PropertyList: React.FC<PropertyListProps> = ({ 
  filters = {}, 
  viewType = 'grid',
  onFiltersChange 
}) => {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 12,
    total: 0,
    totalPages: 0,
    hasNext: false,
    hasPrev: false
  })
  const [searchQuery, setSearchQuery] = useState(filters.query || '')
  const [showFilters, setShowFilters] = useState(false)

  // Function to fetch properties from Supabase Edge Function
  const fetchProperties = useCallback(async (searchFilters: SearchFilters = {}) => {
    setLoading(true)
    setError(null)
    
    try {
      const response = await fetch(
        'https://vprgjpczzswbwcxpnmgf.supabase.co/functions/v1/search-properties',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZwcmdqcGN6enN3YndjeHBubWdmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYzMzY4OTMsImV4cCI6MjA3MTkxMjg5M30.mi0Z16w5BWOGSaBHhemOdESwaFkHwSHOWjYTQ1KP_6Q`
          },
          body: JSON.stringify({
            ...searchFilters,
            page: searchFilters.page || 1,
            limit: searchFilters.limit || 12
          })
        }
      )

      if (!response.ok) {
        throw new Error(`خطأ في الشبكة: ${response.statusText}`)
      }

      const data: SearchResponse = await response.json()
      
      if (data.properties) {
        setProperties(data.properties)
        setPagination(data.pagination)
      } else {
        setError('لم يتم العثور على عقارات')
      }
    } catch (err) {
      console.error('Error fetching properties:', err)
      setError(err instanceof Error ? err.message : 'حدث خطأ في جلب العقارات')
    } finally {
      setLoading(false)
    }
  }, [])

  // Load properties on component mount and when filters change
  useEffect(() => {
    fetchProperties(filters)
  }, [filters, fetchProperties])

  // Handle search input
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const newFilters = { ...filters, query: searchQuery, page: 1 }
    onFiltersChange?.(newFilters)
  }

  // Handle pagination
  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      const newFilters = { ...filters, page: newPage }
      onFiltersChange?.(newFilters)
    }
  }

  // Handle property interactions
  const handleFavorite = (propertyId: string) => {
    // TODO: Implement favorites functionality
    console.log('إضافة للمفضلة:', propertyId)
  }

  const handleContact = (property: Property) => {
    // TODO: Implement contact functionality
    console.log('التواصل مع:', property.owner_name)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600 ml-3" />
        <span className="text-lg text-gray-600">جاري تحميل العقارات...</span>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md mx-auto">
          <h3 className="text-lg font-semibold text-red-800 mb-2">حدث خطأ</h3>
          <p className="text-red-600 mb-4">{error}</p>
          <button
            onClick={() => fetchProperties(filters)}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Search and Filters Bar */}
      <div className="bg-white rounded-lg shadow-sm border p-4">
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن عقارك المثالي..."
                className="w-full pl-4 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                type="submit"
                className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white px-3 py-1.5 rounded-md hover:bg-blue-700 transition-colors text-sm"
              >
                بحث
              </button>
            </div>
          </form>

          {/* View Options and Filters */}
          <div className="flex items-center gap-3">
            {/* Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="text-sm">فلترة</span>
            </button>
          </div>
        </div>

        {/* Results Summary */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
          <div className="text-sm text-gray-600">
            <span className="font-semibold">{pagination.total}</span> عقار متاح
            {filters.query && (
              <span className="mr-2">
                للبحث: <span className="font-semibold">"{filters.query}"</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Properties Grid/List */}
      {properties.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 max-w-md mx-auto">
            <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد عقارات</h3>
            <p className="text-gray-600 mb-4">
              لم نعثر على عقارات تطابق معايير البحث الخاصة بك
            </p>
            <button
              onClick={() => {
                setSearchQuery('')
                onFiltersChange?.({})
              }}
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              مسح الفلاتر
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Properties Grid */}
          <div className={`grid gap-6 ${
            viewType === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
              : 'grid-cols-1'
          }`}>
            {properties.map((property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onFavorite={handleFavorite}
                onContact={handleContact}
              />
            ))}
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="flex items-center justify-center space-x-2 space-x-reverse pt-8">
              <button
                onClick={() => handlePageChange(pagination.page - 1)}
                disabled={!pagination.hasPrev}
                className="px-3 py-2 text-sm border border-gray-300 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
              >
                السابق
              </button>
              
              {Array.from({ length: Math.min(7, pagination.totalPages) }, (_, i) => {
                let pageNum
                if (pagination.totalPages <= 7) {
                  pageNum = i + 1
                } else if (pagination.page <= 4) {
                  pageNum = i + 1
                } else if (pagination.page >= pagination.totalPages - 3) {
                  pageNum = pagination.totalPages - 6 + i
                } else {
                  pageNum = pagination.page - 3 + i
                }
                
                return (
                  <button
                    key={pageNum}
                    onClick={() => handlePageChange(pageNum)}
                    className={`px-3 py-2 text-sm border rounded-md transition-colors ${
                      pageNum === pagination.page
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {pageNum}
                  </button>
                )
              })}
              
              <button
                onClick={() => handlePageChange(pagination.page + 1)}
                disabled={!pagination.hasNext}
                className="px-3 py-2 text-sm border border-gray-300 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
              >
                التالي
              </button>
            </div>
          )}
        </>
      )}
    </div>
  )
}

export default PropertyList