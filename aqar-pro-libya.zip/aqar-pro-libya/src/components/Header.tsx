import React from 'react'
import { Link } from 'react-router-dom'
import { Search, Heart, User, Menu, Phone } from 'lucide-react'

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      {/* Top bar */}
      <div className="bg-blue-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4" />
              <span>+218 91 123 4567</span>
            </div>
            <span>برو - رقم 1 في ليبيا</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="hover:text-blue-200">إضافة عقار</button>
            <button className="hover:text-blue-200">تسجيل دخول</button>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-green-500 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">ع</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">عقار برو</h1>
              <p className="text-sm text-gray-500">عقارات ليبيا</p>
            </div>
          </Link>

          {/* Search bar */}
          <div className="flex-1 max-w-2xl mx-8">
            <div className="relative">
              <input
                type="text"
                placeholder="ابحث عن عقار يناسب احتياجاتك..."
                className="w-full px-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <button className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white px-6 py-1.5 rounded-md hover:bg-blue-700 transition-colors">
                بحث
              </button>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors">
              <Heart className="w-5 h-5" />
              <span>المفضلات</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors">
              <User className="w-5 h-5" />
              <span>حسابي</span>
            </button>
            <button className="lg:hidden">
              <Menu className="w-6 h-6 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8">
              <Link to="/" className="text-blue-600 font-medium hover:text-blue-700">
                الرئيسية
              </Link>
              <Link to="/search?type=sale" className="text-gray-600 hover:text-blue-600 transition-colors">
                عقارات للبيع
              </Link>
              <Link to="/search?type=rent" className="text-gray-600 hover:text-blue-600 transition-colors">
                عقارات للإيجار
              </Link>
              <Link to="/projects" className="text-gray-600 hover:text-blue-600 transition-colors">
                مشاريع عقارية
              </Link>
              <Link to="/agents" className="text-gray-600 hover:text-blue-600 transition-colors">
                وسطاء عقاريين
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button className="px-4 py-2 text-sm bg-white text-blue-600 rounded-md shadow-sm font-medium">
                  قائمة
                </button>
                <button className="px-4 py-2 text-sm text-gray-600 hover:text-blue-600">
                  خريطة
                </button>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
  )
}

export default Header