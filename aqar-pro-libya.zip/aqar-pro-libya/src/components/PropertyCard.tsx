import React from 'react'
import { Heart, Eye, MapPin, Phone, MessageCircle, Car, Wifi, Home } from 'lucide-react'
import { Property } from '@/lib/supabase'

interface PropertyCardProps {
  property: Property
  onFavorite?: (id: string) => void
  onContact?: (property: Property) => void
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onFavorite, onContact }) => {
  const formatPrice = (price: number, currency: string) => {
    const formatter = new Intl.NumberFormat('ar-LY', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })
    return `${formatter.format(price)} ${currency === 'LYD' ? 'د.ل' : currency}`
  }

  const primaryImage = property.images_array?.[0] || '/images/real_estate_app_ui_main_screen_arabic.jpg'
  
  const getListingTypeText = (type: string, period?: string) => {
    if (type === 'rent') {
      switch (period) {
        case 'daily': return 'للإيجار اليومي'
        case 'monthly': return 'للإيجار الشهري'
        case 'yearly': return 'للإيجار السنوي'
        default: return 'للإيجار'
      }
    }
    return 'للبيع'
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow duration-300">
      {/* Image */}
      <div className="relative">
        <img
          src={primaryImage}
          alt={property.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-3 right-3">
          <button
            onClick={() => onFavorite?.(property.id)}
            className="p-2 bg-white/90 rounded-full hover:bg-white transition-colors"
          >
            <Heart className="w-4 h-4 text-gray-600 hover:text-red-500" />
          </button>
        </div>
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            property.listing_type === 'sale' 
              ? 'bg-green-100 text-green-800'
              : 'bg-blue-100 text-blue-800'
          }`}>
            {getListingTypeText(property.listing_type, property.rental_period)}
          </span>
        </div>
        <div className="absolute bottom-3 left-3 flex items-center gap-1 bg-black/50 text-white px-2 py-1 rounded text-xs">
          <Eye className="w-3 h-3" />
          <span>{property.views_count}</span>
        </div>
        {property.is_featured && (
          <div className="absolute bottom-3 right-3">
            <span className="bg-yellow-500 text-white px-2 py-1 rounded text-xs font-medium">
              مميز
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Price */}
        <div className="mb-3">
          <div className="text-2xl font-bold text-blue-600">
            {formatPrice(property.price, property.currency)}
          </div>
          {property.rental_period && (
            <div className="text-sm text-gray-500">
              /{property.rental_period === 'daily' ? 'يوم' : property.rental_period === 'monthly' ? 'شهر' : 'سنة'}
            </div>
          )}
        </div>

        {/* Title */}
        <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-2">
          {property.title}
        </h3>

        {/* Location */}
        <div className="flex items-center gap-2 text-gray-600 mb-3">
          <MapPin className="w-4 h-4 flex-shrink-0" />
          <span className="text-sm">
            {property.district_name}، {property.city_name}
          </span>
        </div>

        {/* Property details */}
        <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
          {property.area && (
            <div className="flex items-center gap-1">
              <Home className="w-4 h-4" />
              <span>{property.area} م²</span>
            </div>
          )}
          {property.bedrooms > 0 && (
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 flex items-center justify-center text-xs border rounded">غ</span>
              <span>{property.bedrooms}</span>
            </div>
          )}
          {property.bathrooms > 0 && (
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 flex items-center justify-center text-xs border rounded">ح</span>
              <span>{property.bathrooms}</span>
            </div>
          )}
        </div>

        {/* Amenities */}
        {property.amenities_array?.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {property.amenities_array.slice(0, 3).map((amenity, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
              >
                {amenity}
              </span>
            ))}
            {property.amenities_array.length > 3 && (
              <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                +{property.amenities_array.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Owner info */}
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-blue-600 text-sm font-medium">
                {property.owner_name?.[0] || 'ع'}
              </span>
            </div>
            <div>
              <div className="text-sm font-medium text-gray-800">
                {property.owner_name || 'معلن'}
              </div>
              {property.owner_verified && (
                <div className="text-xs text-green-600">موثق</div>
              )}
            </div>
          </div>

          {/* Contact buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onContact?.(property)}
              className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              title="اتصال"
            >
              <Phone className="w-4 h-4" />
            </button>
            {property.contact_whatsapp && (
              <button
                onClick={() => window.open(`https://wa.me/${property.contact_whatsapp.replace(/[^\d]/g, '')}`, '_blank')}
                className="p-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                title="واتساب"
              >
                <MessageCircle className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default PropertyCard