import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, MapPin, TrendingUp, Star, ArrowRight, Home, Building, MapIcon } from 'lucide-react'
import PropertyCard from '@/components/PropertyCard'
import { usePropertySearch, useCities, usePropertyTypes } from '@/hooks/useProperty'
import { Property, SearchFilters } from '@/lib/supabase'

const HomePage: React.FC = () => {
  const navigate = useNavigate()
  const { searchProperties, data, loading } = usePropertySearch()
  const { cities } = useCities()
  const { propertyTypes } = usePropertyTypes()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCity, setSelectedCity] = useState('')
  const [selectedType, setSelectedType] = useState('')
  const [selectedListingType, setSelectedListingType] = useState<'sale' | 'rent'>('sale')

  useEffect(() => {
    // Load initial properties
    searchProperties({ limit: 12 })
  }, [])

  const handleSearch = () => {
    const filters: SearchFilters = {
      query: searchQuery || undefined,
      cityId: selectedCity ? parseInt(selectedCity) : undefined,
      propertyTypeId: selectedType ? parseInt(selectedType) : undefined,
      listingType: selectedListingType,
      limit: 12
    }
    
    const queryParams = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== '') {
        queryParams.set(key, value.toString())
      }
    })
    
    navigate(`/search?${queryParams.toString()}`)
  }

  const handlePropertyContact = (property: Property) => {
    if (property.contact_phone) {
      window.open(`tel:${property.contact_phone}`, '_blank')
    }
  }

  const handlePropertyFavorite = (id: string) => {
    // TODO: Implement favorites functionality
    console.log('Add to favorites:', id)
  }

  const featuredProperties = data?.properties?.filter(p => p.is_featured).slice(0, 3) || []
  const recentProperties = data?.properties?.slice(0, 8) || []
  const majorCities = cities.filter(c => c.is_major_city).slice(0, 5)

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-green-600 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              عثر على عقارك المثالي
              <br />
              <span className="text-yellow-300">في ليبيا</span>
            </h1>
            <p className="text-xl opacity-90 mb-8">
              منصة عقار برو - منزلك، معنا
            </p>
            
            {/* Advanced Search */}
            <div className="bg-white rounded-2xl shadow-2xl p-6 text-right">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="flex bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => setSelectedListingType('sale')}
                    className={`flex-1 px-6 py-2 rounded-md font-medium transition-colors ${
                      selectedListingType === 'sale'
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    للبيع
                  </button>
                  <button
                    onClick={() => setSelectedListingType('rent')}
                    className={`flex-1 px-6 py-2 rounded-md font-medium transition-colors ${
                      selectedListingType === 'rent'
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    للإيجار
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="ابحث بالكلمات..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pr-10 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                  />
                </div>
                
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                >
                  <option value="">جميع الأنواع</option>
                  {propertyTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.name_ar}</option>
                  ))}
                </select>
                
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                >
                  <option value="">جميع المدن</option>
                  {cities.map(city => (
                    <option key={city.id} value={city.id}>{city.name_ar}</option>
                  ))}
                </select>
                
                <button
                  onClick={handleSearch}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center gap-2"
                >
                  <Search className="w-5 h-5" />
                  بحث
                </button>
              </div>
              
              <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                <span>بحث شائع:</span>
                {['فلل طرابلس', 'شقق بنغازي', 'أراضي للبيع', 'استراحات'].map((tag, index) => (
                  <button
                    key={index}
                    onClick={() => setSearchQuery(tag)}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: '10,000+', label: 'عقار متاح', icon: Home },
            { number: '2,500+', label: 'عميل راض', icon: Star },
            { number: '15', label: 'مدينة ليبية', icon: MapPin },
            { number: '50+', label: 'وسيط عقاري', icon: Building }
          ].map((stat, index) => (
            <div key={index} className="text-center bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{stat.number}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Properties */}
      {featuredProperties.length > 0 && (
        <section className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">عقارات مميزة</h2>
            <button 
              onClick={() => navigate('/search?featured=true')}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              عرض الكل
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProperties.map(property => (
              <PropertyCard
                key={property.id}
                property={property}
                onFavorite={handlePropertyFavorite}
                onContact={handlePropertyContact}
              />
            ))}
          </div>
        </section>
      )}

      {/* Browse by Cities */}
      <section className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">تصفح حسب المدينة</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {majorCities.map(city => (
            <button
              key={city.id}
              onClick={() => navigate(`/search?cityId=${city.id}`)}
              className="group bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-all hover:border-blue-300"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <MapIcon className="w-6 h-6 text-white" />
              </div>
              <div className="font-semibold text-gray-800 mb-1">{city.name_ar}</div>
              <div className="text-sm text-gray-500">
                {city.population ? `${Math.round(city.population / 1000)}K نسمة` : 'مدينة رئيسية'}
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Recent Properties */}
      <section className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">عقارات حديثة</h2>
          <button 
            onClick={() => navigate('/search')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
          >
            عرض الكل
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden animate-pulse">
                <div className="w-full h-48 bg-gray-300"></div>
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-300 rounded w-1/2"></div>
                  <div className="h-4 bg-gray-300 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentProperties.map(property => (
              <PropertyCard
                key={property.id}
                property={property}
                onFavorite={handlePropertyFavorite}
                onContact={handlePropertyContact}
              />
            ))}
          </div>
        )}
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-green-600 text-white">
        <div className="container mx-auto px-4 py-16 text-center">
          <h2 className="text-3xl font-bold mb-4">هل تريد بيع عقارك؟</h2>
          <p className="text-xl opacity-90 mb-8">
            انضم إلى آلاف المعلنين الذين وثقوا في عقار برو
          </p>
          <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors">
            أضف عقارك الآن
          </button>
        </div>
      </section>
    </div>
  )
}

export default HomePage