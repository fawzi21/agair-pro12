import React, { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import { SlidersHorizontal, Grid3X3, List, Search } from 'lucide-react'
import PropertyList from '@/components/PropertyList'
import { SearchFilters } from '@/lib/supabase'

const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [showFilters, setShowFilters] = useState(false)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  
  // Parse initial filters from URL
  const [filters, setFilters] = useState<SearchFilters>(() => {
    const initialFilters: SearchFilters = {
      page: 1,
      limit: 20,
      sortBy: 'created_at',
      sortOrder: 'desc'
    }
    
    // Parse URL parameters
    const query = searchParams.get('query')
    if (query) initialFilters.query = query
    
    const cityId = searchParams.get('cityId')
    if (cityId) initialFilters.cityId = parseInt(cityId)
    
    const districtId = searchParams.get('districtId')
    if (districtId) initialFilters.districtId = parseInt(districtId)
    
    const propertyTypeId = searchParams.get('propertyTypeId')
    if (propertyTypeId) initialFilters.propertyTypeId = parseInt(propertyTypeId)
    
    const listingType = searchParams.get('listingType')
    if (listingType === 'sale' || listingType === 'rent') initialFilters.listingType = listingType
    
    const minPrice = searchParams.get('minPrice')
    if (minPrice) initialFilters.minPrice = parseFloat(minPrice)
    
    const maxPrice = searchParams.get('maxPrice')
    if (maxPrice) initialFilters.maxPrice = parseFloat(maxPrice)
    
    const minArea = searchParams.get('minArea')
    if (minArea) initialFilters.minArea = parseFloat(minArea)
    
    const maxArea = searchParams.get('maxArea')
    if (maxArea) initialFilters.maxArea = parseFloat(maxArea)
    
    const bedrooms = searchParams.get('bedrooms')
    if (bedrooms) initialFilters.bedrooms = parseInt(bedrooms)
    
    const bathrooms = searchParams.get('bathrooms')
    if (bathrooms) initialFilters.bathrooms = parseInt(bathrooms)
    
    const sortBy = searchParams.get('sortBy')
    if (sortBy) initialFilters.sortBy = sortBy
    
    const sortOrder = searchParams.get('sortOrder')
    if (sortOrder === 'asc' || sortOrder === 'desc') initialFilters.sortOrder = sortOrder
    
    return initialFilters
  })
  
  // Update URL when filters change
  const updateURL = (newFilters: SearchFilters) => {
    const params = new URLSearchParams()
    
    Object.entries(newFilters).forEach(([key, value]) => {
      if (value !== undefined && value !== '' && value !== null) {
        params.set(key, value.toString())
      }
    })
    
    setSearchParams(params)
  }
  
  // Handle filters change from PropertyList component
  const handleFiltersChange = (newFilters: SearchFilters) => {
    setFilters(newFilters)
    updateURL(newFilters)
  }
  
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Page Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">نتائج البحث</h1>
          <p className="text-gray-600">
            ابحث عن عقارك المثالي من بين آلاف العقارات المتاحة في ليبيا
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
              title="عرض الشبكة"
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
              title="عرض القائمة"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
      
      {/* PropertyList Component */}
      <PropertyList
        filters={filters}
        viewType={viewMode}
        onFiltersChange={handleFiltersChange}
      />
    </div>
  )
}

export default SearchPage