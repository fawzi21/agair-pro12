import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, Heart, Share2, Eye, MapPin, Home, Phone, MessageCircle, Car, Wifi, Calendar, User, Star } from 'lucide-react'
import { Property, supabase } from '@/lib/supabase'

const PropertyDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    if (id) {
      fetchPropertyDetails(id)
    }
  }, [id])

  const fetchPropertyDetails = async (propertyId: string) => {
    setLoading(true)
    try {
      // Since we don't have direct property details endpoint, 
      // we'll search for the specific property
      const { data: response, error } = await supabase.functions.invoke('property-search', {
        body: { limit: 1, page: 1 }
      })

      if (error) {
        throw new Error(error.message)
      }

      if (response?.error) {
        throw new Error(response.error.message)
      }

      // For demo purposes, we'll use the first property if ID matches
      // In a real app, you'd search by specific ID
      const properties = response.data.properties
      const foundProperty = properties.find((p: Property) => p.id === propertyId) || properties[0]
      
      if (foundProperty) {
        setProperty(foundProperty)
        // Update view count (in a real app, this would be done server-side)
        // updateViewCount(propertyId)
      } else {
        throw new Error('لم يتم العثور على العقار')
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'حدث خطأ في جلب تفاصيل العقار'
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number, currency: string) => {
    const formatter = new Intl.NumberFormat('ar-LY', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })
    return `${formatter.format(price)} ${currency === 'LYD' ? 'د.ل' : currency}`
  }

  const getListingTypeText = (type: string, period?: string) => {
    if (type === 'rent') {
      switch (period) {
        case 'daily': return 'للإيجار اليومي'
        case 'monthly': return 'للإيجار الشهري'
        case 'yearly': return 'للإيجار السنوي'
        default: return 'للإيجار'
      }
    }
    return 'للبيع'
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: property?.title,
          text: property?.description,
          url: window.location.href
        })
      } catch (err) {
        console.log('Error sharing:', err)
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href)
      // Show toast or notification
    }
  }

  const handleContact = () => {
    if (property?.contact_phone) {
      window.open(`tel:${property.contact_phone}`, '_blank')
    }
  }

  const handleWhatsApp = () => {
    if (property?.contact_whatsapp) {
      const phoneNumber = property.contact_whatsapp.replace(/[^\d]/g, '')
      const message = encodeURIComponent(`مرحبا، أنا مهتم بالعقار: ${property.title}`)
      window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank')
    }
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
    // TODO: Implement actual favorite functionality
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-1/4 mb-6"></div>
          <div className="h-64 bg-gray-300 rounded-lg mb-6"></div>
          <div className="space-y-4">
            <div className="h-6 bg-gray-300 rounded w-3/4"></div>
            <div className="h-4 bg-gray-300 rounded w-1/2"></div>
            <div className="h-4 bg-gray-300 rounded w-2/3"></div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Home className="w-8 h-8 text-red-500" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">خطأ في تحميل العقار</h3>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={() => navigate('/search')}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            عودة إلى البحث
          </button>
        </div>
      </div>
    )
  }

  if (!property) {
    return null
  }

  // Default to placeholder images if none available
  const images = property.images_array?.length > 0 
    ? property.images_array 
    : ['/images/real_estate_app_ui_main_screen_arabic.jpg']

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Back button */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-gray-600 hover:text-blue-600 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        عودة
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Images and main info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Image Gallery */}
          <div className="relative">
            <div className="aspect-video rounded-2xl overflow-hidden">
              <img
                src={images[currentImageIndex]}
                alt={property.title}
                className="w-full h-full object-cover"
              />
              {property.is_featured && (
                <div className="absolute top-4 left-4">
                  <span className="bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    مميز
                  </span>
                </div>
              )}
              <div className="absolute top-4 right-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  property.listing_type === 'sale' 
                    ? 'bg-green-100 text-green-800'
                    : 'bg-blue-100 text-blue-800'
                }`}>
                  {getListingTypeText(property.listing_type, property.rental_period)}
                </span>
              </div>
              <div className="absolute bottom-4 left-4 flex items-center gap-1 bg-black/50 text-white px-2 py-1 rounded text-sm">
                <Eye className="w-4 h-4" />
                <span>{property.views_count} مشاهدة</span>
              </div>
            </div>
            
            {/* Image thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto">
                {images.slice(0, 6).map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                      currentImageIndex === index 
                        ? 'border-blue-500' 
                        : 'border-transparent'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${property.title} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
                {images.length > 6 && (
                  <div className="flex-shrink-0 w-20 h-16 rounded-lg bg-gray-100 flex items-center justify-center text-gray-600 text-sm">
                    +{images.length - 6}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Property Details */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-800 mb-2">{property.title}</h1>
                <div className="flex items-center gap-2 text-gray-600 mb-4">
                  <MapPin className="w-5 h-5" />
                  <span>{property.address_details}</span>
                </div>
                <div className="text-sm text-gray-500">
                  {property.district_name}، {property.city_name}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleFavorite}
                  className={`p-2 rounded-full border-2 transition-colors ${
                    isFavorite
                      ? 'border-red-500 bg-red-50 text-red-500'
                      : 'border-gray-300 hover:border-red-300 hover:bg-red-50'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                </button>
                <button
                  onClick={handleShare}
                  className="p-2 border-2 border-gray-300 rounded-full hover:border-blue-300 hover:bg-blue-50 transition-colors"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Price */}
            <div className="mb-6 p-4 bg-blue-50 rounded-xl">
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {formatPrice(property.price, property.currency)}
              </div>
              {property.rental_period && (
                <div className="text-blue-600">
                  /{property.rental_period === 'daily' ? 'يوم' : property.rental_period === 'monthly' ? 'شهر' : 'سنة'}
                </div>
              )}
            </div>

            {/* Key Details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {property.area && (
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <Home className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <div className="font-semibold text-gray-800">{property.area} م²</div>
                  <div className="text-sm text-gray-600">المساحة</div>
                </div>
              )}
              {property.bedrooms > 0 && (
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 text-sm font-bold">
                    غ
                  </div>
                  <div className="font-semibold text-gray-800">{property.bedrooms}</div>
                  <div className="text-sm text-gray-600">غرف نوم</div>
                </div>
              )}
              {property.bathrooms > 0 && (
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 text-sm font-bold">
                    ح
                  </div>
                  <div className="font-semibold text-gray-800">{property.bathrooms}</div>
                  <div className="text-sm text-gray-600">حمامات</div>
                </div>
              )}
              {property.floor_number && (
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 text-sm font-bold">
                    {property.floor_number}
                  </div>
                  <div className="font-semibold text-gray-800">الطابق</div>
                  <div className="text-sm text-gray-600">{property.floor_number}</div>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">وصف العقار</h3>
              <p className="text-gray-600 leading-relaxed">{property.description}</p>
            </div>

            {/* Amenities */}
            {property.amenities_array?.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">المرافق والخدمات</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {property.amenities_array.map((amenity, index) => (
                    <div key={index} className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-gray-700">{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Additional Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">معلومات إضافية</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">نوع العقار:</span>
                    <span className="font-medium">{property.property_type_name}</span>
                  </div>
                  {property.property_age !== undefined && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">عمر العقار:</span>
                      <span className="font-medium">{property.property_age} سنوات</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">تاريخ النشر:</span>
                    <span className="font-medium">
                      {new Date(property.created_at).toLocaleDateString('ar-LY')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">رقم العقار:</span>
                    <span className="font-medium font-mono">{property.id.slice(0, 8)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Card */}
        <div className="space-y-6">
          {/* Owner Info */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 sticky top-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-blue-600 text-xl font-bold">
                  {property.owner_name?.[0] || 'ع'}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-gray-800">{property.owner_name || 'معلن'}</h3>
              {property.owner_verified && (
                <div className="flex items-center justify-center gap-1 text-green-600 text-sm mt-1">
                  <Star className="w-4 h-4 fill-current" />
                  <span>موثق</span>
                </div>
              )}
            </div>

            {/* Contact Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleContact}
                className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors font-medium"
              >
                <Phone className="w-5 h-5" />
                اتصال مباشر
              </button>
              
              {property.contact_whatsapp && (
                <button
                  onClick={handleWhatsApp}
                  className="w-full flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-xl hover:bg-green-700 transition-colors font-medium"
                >
                  <MessageCircle className="w-5 h-5" />
                  واتساب
                </button>
              )}

              <div className="text-center pt-3 border-t border-gray-100">
                <p className="text-sm text-gray-600">
                  اتصل من الساعة 9 صباحاً إلى 9 مساءً
                </p>
              </div>
            </div>
          </div>

          {/* Safety Tips */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
            <h4 className="text-lg font-semibold text-yellow-800 mb-3">نصائح للأمان</h4>
            <ul className="text-sm text-yellow-700 space-y-2">
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                <span>قم بمعاينة العقار قبل الدفع</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                <span>لا تقم بإيداع أموال بدون رؤية العقار</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                <span>تأكد من هوية المالك والوسيط</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PropertyDetailsPage