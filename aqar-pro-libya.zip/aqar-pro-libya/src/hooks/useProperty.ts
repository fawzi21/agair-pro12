import { useState, useEffect } from 'react'
import { supabase, type SearchFilters, type SearchResponse } from '@/lib/supabase'

export function usePropertySearch() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [data, setData] = useState<SearchResponse | null>(null)

  const searchProperties = async (filters: SearchFilters = {}) => {
    setLoading(true)
    setError(null)
    
    try {
      const { data: response, error } = await supabase.functions.invoke('property-search', {
        body: filters
      })

      if (error) {
        throw new Error(error.message)
      }

      if (response?.error) {
        throw new Error(response.error.message)
      }

      setData(response.data)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'حدث خطأ في البحث'
      setError(errorMessage)
      console.error('Property search error:', err)
    } finally {
      setLoading(false)
    }
  }

  return {
    searchProperties,
    loading,
    error,
    data,
    clearError: () => setError(null)
  }
}

export function useCities() {
  const [cities, setCities] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchCities = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase
          .from('cities')
          .select('*')
          .order('is_major_city', { ascending: false })
          .order('population', { ascending: false })

        if (error) throw error
        setCities(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'حدث خطأ في جلب المدن')
      } finally {
        setLoading(false)
      }
    }

    fetchCities()
  }, [])

  return { cities, loading, error }
}

export function usePropertyTypes() {
  const [propertyTypes, setPropertyTypes] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchPropertyTypes = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase
          .from('property_types')
          .select('*')
          .eq('is_active', true)
          .order('display_order')

        if (error) throw error
        setPropertyTypes(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'حدث خطأ في جلب أنواع العقارات')
      } finally {
        setLoading(false)
      }
    }

    fetchPropertyTypes()
  }, [])

  return { propertyTypes, loading, error }
}

export function useDistricts(cityId?: number) {
  const [districts, setDistricts] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!cityId) {
      setDistricts([])
      return
    }

    const fetchDistricts = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase
          .from('districts')
          .select('*')
          .eq('city_id', cityId)
          .order('name_ar')

        if (error) throw error
        setDistricts(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'حدث خطأ في جلب الأحياء')
      } finally {
        setLoading(false)
      }
    }

    fetchDistricts()
  }, [cityId])

  return { districts, loading, error }
}