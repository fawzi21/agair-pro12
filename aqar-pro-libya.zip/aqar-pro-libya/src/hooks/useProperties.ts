import { useState, useEffect, useCallback } from 'react'
import { Property, SearchFilters, SearchResponse } from '@/lib/supabase'

interface UsePropertiesReturn {
  properties: Property[]
  loading: boolean
  error: string | null
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
    hasNext: boolean
    hasPrev: boolean
  }
  searchProperties: (filters: SearchFilters) => Promise<void>
  refreshProperties: () => Promise<void>
  clearError: () => void
}

const SUPABASE_URL = 'https://vprgjpczzswbwcxpnmgf.supabase.co'
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZwcmdqcGN6enN3YndjeHBubWdmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYzMzY4OTMsImV4cCI6MjA3MTkxMjg5M30.mi0Z16w5BWOGSaBHhemOdESwaFkHwSHOWjYTQ1KP_6Q'

export const useProperties = (initialFilters: SearchFilters = {}): UsePropertiesReturn => {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [currentFilters, setCurrentFilters] = useState<SearchFilters>(initialFilters)
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 12,
    total: 0,
    totalPages: 0,
    hasNext: false,
    hasPrev: false
  })

  const searchProperties = useCallback(async (filters: SearchFilters = {}) => {
    setLoading(true)
    setError(null)
    setCurrentFilters(filters)
    
    try {
      const searchPayload = {
        query: filters.query || '',
        cityId: filters.cityId,
        districtId: filters.districtId,
        propertyTypeId: filters.propertyTypeId,
        listingType: filters.listingType,
        minPrice: filters.minPrice,
        maxPrice: filters.maxPrice,
        minArea: filters.minArea,
        maxArea: filters.maxArea,
        bedrooms: filters.bedrooms,
        bathrooms: filters.bathrooms,
        page: filters.page || 1,
        limit: filters.limit || 12,
        sortBy: filters.sortBy || 'created_at',
        sortOrder: filters.sortOrder || 'desc'
      }

      console.log('Searching properties with filters:', searchPayload)

      const response = await fetch(
        `${SUPABASE_URL}/functions/v1/search-properties`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'apikey': SUPABASE_ANON_KEY
          },
          body: JSON.stringify(searchPayload)
        }
      )

      if (!response.ok) {
        const errorText = await response.text()
        console.error('API Error Response:', errorText)
        throw new Error(`خطأ في الشبكة: ${response.status} ${response.statusText}`)
      }

      const data: SearchResponse = await response.json()
      console.log('API Response:', data)
      
      if (data.properties && Array.isArray(data.properties)) {
        setProperties(data.properties)
        if (data.pagination) {
          setPagination(data.pagination)
        } else {
          // Fallback pagination if not provided
          setPagination({
            page: searchPayload.page,
            limit: searchPayload.limit,
            total: data.properties.length,
            totalPages: 1,
            hasNext: false,
            hasPrev: false
          })
        }
      } else {
        console.warn('No properties in response:', data)
        setProperties([])
        setPagination({
          page: 1,
          limit: 12,
          total: 0,
          totalPages: 0,
          hasNext: false,
          hasPrev: false
        })
      }
    } catch (err) {
      console.error('Error fetching properties:', err)
      const errorMessage = err instanceof Error ? err.message : 'حدث خطأ في جلب العقارات'
      setError(errorMessage)
      setProperties([])
      setPagination({
        page: 1,
        limit: 12,
        total: 0,
        totalPages: 0,
        hasNext: false,
        hasPrev: false
      })
    } finally {
      setLoading(false)
    }
  }, [])

  const refreshProperties = useCallback(async () => {
    await searchProperties(currentFilters)
  }, [currentFilters, searchProperties])

  const clearError = useCallback(() => {
    setError(null)
  }, [])

  // Load properties on initial mount
  useEffect(() => {
    searchProperties(initialFilters)
  }, []) // Only run once on mount

  return {
    properties,
    loading,
    error,
    pagination,
    searchProperties,
    refreshProperties,
    clearError
  }
}